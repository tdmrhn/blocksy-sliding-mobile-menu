<?php
/*
Plugin Name: Blocksy Custom Sliding Mobile Menu
Plugin URI: https://dmrhn.com
Description: Custom sliding mobile menu. Works for Content Blocks > WP Core Navigation Block (add ct-sliding class).
Version: 0.3
Author: dmrhn
Author URI: https://dmrhn.com
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: blocksy-sliding-mobile-menu
*/

add_action('wp_enqueue_scripts', function () {
    $plugin_data = get_file_data(__FILE__, array('Version' => 'Version'));
    $version = $plugin_data['Version'];

    wp_enqueue_style('blocksy-sliding-menu-styles', plugin_dir_url(__FILE__) . 'styles.min.css', array(), $version, 'all');
    wp_enqueue_script('blocksy-sliding-menu-script', plugin_dir_url(__FILE__) . 'script.min.js', array(), $version, true);
}, 90);
